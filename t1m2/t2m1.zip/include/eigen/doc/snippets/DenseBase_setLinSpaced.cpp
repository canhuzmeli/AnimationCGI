VectorXf v;
v.setLinSpaced(0.5f,1.5f,5).transpose();
cout << v << endl;
